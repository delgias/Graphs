#include <iostream>
#include "cstring"
#include <queue>
#include "graph.h"
using namespace std;

MyGraph::MyGraph (int c, int b)
	{
		this -> V = c;
		this -> E = b;
		this -> a = new int* [c];
		this -> root = 0;
	    for (int i = 0; i < c; i++)
	    {
		    a [i] = new int [c];
	    }

		for (int i = 0; i < c; i++)
		{
			for (int j = 0; j < c; j++)
			{
				a [i][j] = 0;
			}
		}
		this -> val = new int [c];
		for (int i = 0; i < c; ++i)
		{
			val [i] = 0;
		}

		this -> count = 0;
	}

	MyGraph::MyGraph (const MyGraph& g)
	{
		V = g.V;
		E = g.E;
		
		for (int i = 0; i < g.V; i++)
			{
				for (int j = 0; j < g.V; j++)
				{
					a [i][j] = g.a [i][j];
				}
			}

		for (int i = 0; i < g.V; ++i)
		{
			val [i] = g.val [i];
		}
		count = g.count;
		root = g.root;
	}

	MyGraph::~MyGraph (void)
	{
		delete [] a;
		delete [] val;
	}

	void MyGraph::setCount (int i)
	{
		this -> count = i;
	}

	void MyGraph::setV (int v)
	{
		this -> V = v;
	}

	void MyGraph::setE (int e)
	{
		this -> E = e;
	}

	void MyGraph::setVal (int i, int x)
	{
		val [i] = x;
	}

	void MyGraph::setA (int i, int j, int x)
	{
		a [i][j] = x;
	}

	int MyGraph::getV ()
	{
		return V;
	}

	int MyGraph::getE ()
	{
		return E;
	}

	int MyGraph::getCount ()
	{
		return count;
	}

	int MyGraph::getVal (int i)
	{
		return val [i];
	}

	int MyGraph::getA (int i, int j)
	{
		return this -> a[i][j];
	}

	void MyGraph::printGraph ()
	{
		cout << "Adjacency matrix is ..." << endl << endl;
		for (int i = 0; i < V; ++i)
		{
			for (int j = 0; j < V; ++j)
			{
				cout << a[i][j] << " ";
			}
			cout << endl;
		}
		cout << endl << endl;
	}

	void MyGraph::BFS ()
	{
		cout << endl << endl;
		cout << "Carrying out BFS ..." << endl;
		for (int i = 0; i < V; ++i)
		{
			val[i] = 0;
		}
		count = 0;
		for (int k = 0; k < V; k++)
		{
			if (val[k] == 0)
			{
				cout << endl;
				cout <<  "Connected Component:  ";
				visitBFS (k);
			}
		}
		cout << endl << endl;
	}

	void MyGraph::visitBFS (int k)
	{
		count = count + 1;
		val[k] = count;

		queue<int> queue1;

		queue1.push (k);
		int m;
		while (!queue1.empty ())
		{
			m = queue1.front ();
			queue1.pop ();


			for (int w = 0; w < V; w++)
			{
				if (val[w] == 0 && a[m][w] != 0)
			//	if (val[w] == 0 && a[w])
				{
					cout << "(" << m << "," << w << ") "; 
					count = count + 1;
					val[w] = count;
					queue1.push(w);
				}
			}
		}

	}


	void MyGraph::DFS ()
	{
		cout << "Carrying out DFS ..." << endl;
		for (int i = 0; i < V; i++)
		{
			val[i] = 0;
		}
		count = 0;
		for (int k = 0; k < V; k++)
		{
			if (val[k] == 0)
			{
				cout << endl;
				cout << "Connected Components:  ";
				visitDFS (k);
			}
		}
		cout << endl << endl;
	}

	void MyGraph::visitDFS (int k)
	{
		count = count + 1;
		val [k] = count;
		for (int w = 0; w < V; w++)
		{
			if (val[w] == 0 && a[k][w] != 0)
			{
				cout << "(" << k << "," << w << ") "; 
				//val[w] = 0;
				visitDFS (w);
			}
		}
	}

	void MyGraph::ArtPts ()
	{
		cout << "Searching for articulation points ..." << endl;
		for (int i = 0; i < V; i++)
		{
			val[i] = 0;
		}
		count = 0;
		for (int k = 0; k < V; k++)
		{
			if (val[k] == 0)
			{
				root = k;
				visitDFSArtPts (k);
			}
		}
	}
	   
	int MyGraph::visitDFSArtPts (int k)
	{
		int min;

		count = count + 1;
		val [k] = count;
		min = count;
		for (int w = 0; w < V; w++)
		{
			if (a[k][w] != 0)
			{
				if (val[w] == 0)
				{

					int m = visitDFSArtPts (w);
					if (k == root)
					{
						for (int z = 0; z < V; z++)
						{
							if (val[z] == 0 && a[k][z] != 0)
							{
								cout << k << " ";
							}
						}
					}

					if (m < min)
					{
						min = m;
					}

					if (m >= val[k] && k != root)
					{
						cout << k << " ";
					}
				}

				else if (val[w] < min)
				{
					min = val [w];
				}
			}
		}
	return min;
	}