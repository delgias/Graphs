	class MyGraph
	{
	private:
		int V; // number of vertices, dimensions
		int E;
		int **a;
		int* val;
		int count;
		int root;
	public:
		MyGraph (int c, int b);
		MyGraph ( const MyGraph& g);
		~MyGraph (void);
		void setCount (int i);
		void setV (int v);
		void setE (int e);
		void setVal (int i, int x);
		void setA (int i, int j, int x);
		int getV ();
		int getE ();
		int getCount ();
		int getVal (int i);
		int getA (int i, int j);
		void printGraph ();
		void BFS ();
		void visitBFS (int k);
		void DFS ();
		void visitDFS (int k);
		void ArtPts ();
		int visitDFSArtPts (int k);
	};