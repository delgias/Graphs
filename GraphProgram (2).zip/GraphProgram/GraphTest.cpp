#include <iostream>
#include "cstring"
#include <queue>
#include "graph.h"
using namespace std;

int main ()
{
MyGraph G1(4, 3);
G1.setA(0,1,1); 
G1.setA(1,0,1); 
G1.setA(1,2,1); 
G1.setA(2,1,1); 
G1.setA(1,3,1); 
G1.setA(3,1,1); 
  
MyGraph G2(6, 10);
G2.setA(0,1,1); 
G2.setA(1,0,1); 
G2.setA(0,2,1); 
G2.setA(2,0,1); 
G2.setA(0,3,1); 
G2.setA(3,0,1); 
G2.setA(0,4,1); 
G2.setA(4,0,1); 
G2.setA(1,2,1); 
G2.setA(2,1,1); 
G2.setA(2,4,1); 
G2.setA(4,2,1); 
G2.setA(2,5,1); 
G2.setA(5,2,1); 
G2.setA(3,4,1); 
G2.setA(4,3,1); 
G2.setA(3,5,1); 
G2.setA(5,3,1); 
G2.setA(4,5,1); 
G2.setA(5,4,1); 
  
MyGraph G3(13, 17);
  
G3.setA(0,1,1); 
G3.setA(1,0,1); 
G3.setA(0,5,1); 
G3.setA(5,0,1); 
G3.setA(0,6,1); 
G3.setA(6,0,1); 
G3.setA(0,2,1); 
G3.setA(2,0,1); 
G3.setA(2,6,1); 
G3.setA(6,2,1); 
G3.setA(4,3,1); 
G3.setA(3,4,1); 
G3.setA(3,5,1); 
G3.setA(5,3,1); 
G3.setA(4,5,1); 
G3.setA(5,4,1); 
G3.setA(4,6,1); 
G3.setA(6,4,1); 
G3.setA(6,7,1); 
G3.setA(7,6,1); 
G3.setA(6,11,1); 
G3.setA(11,6,1); 
G3.setA(6,9,1); 
G3.setA(9,6,1); 
G3.setA(7,8,1); 
G3.setA(8,7,1); 
G3.setA(9,10,1); 
G3.setA(10,9,1); 
G3.setA(9,11,1); 
G3.setA(11,9,1); 
G3.setA(9,12,1); 
G3.setA(12,9,1); 
G3.setA(11,12,1); 
G3.setA(12,11,1); 
  
MyGraph G4(5,4);
  
G4.setA(0,1,1); 
G4.setA(1,0,1); 
G4.setA(0,2,1); 
G4.setA(2,0,1); 
G4.setA(1,2,1); 
G4.setA(2,1,1); 
G4.setA(3,4,1); 
G4.setA(4,3,1); 
  
MyGraph G5(10,14);
G5.setA(0,3,1); 
G5.setA(3,0,1); 
G5.setA(2,2,1); 
G5.setA(3,5,1); 
G5.setA(5,3,1); 
G5.setA(8,9,1); 
G5.setA(9,8,1); 
G5.setA(0,5,1); 
G5.setA(5,0,1); 
G5.setA(8,3,1); 
G5.setA(3,8,1); 
G5.setA(5,9,1); 
G5.setA(9,5,1); 
G5.setA(3,9,1); 
G5.setA(9,3,1); 
G5.setA(8,3,1); 
G5.setA(3,8,1); 
G5.setA(1,7,1); 
G5.setA(7,1,1); 
G5.setA(4,6,1); 
G5.setA(6,4,1); 
G5.setA(6,7,1); 
G5.setA(7,6,1); 
G5.setA(1,4,1); 
G5.setA(4,1,1); 
G5.setA(1,6,1); 
G5.setA(6,1,1); 
G5.setA(4,7,1); 
G5.setA(7,4,1); 



G1.printGraph ();
int x;
cout << "Neighbors of second node are:  ";
for (int i = 0; i < G1.getV (); i++)
{
	x = G1.getA (1,i);
	if (x == 1)
	{
		cout << i << " ";
	}
}
G1.BFS ();
G1.DFS ();
G1.ArtPts ();
cout << endl << "________________________________________________________________________________" << endl << endl;

G2.printGraph ();
cout << "Neighbors of second node are:  ";
for (int i = 0; i < G2.getV (); i++)
{
	x = G2.getA (1,i);
	if (x == 1)
	{
		cout << i << " ";
	}
}
G2.BFS ();
G2.DFS ();
G2.ArtPts ();
cout << endl << "________________________________________________________________________________" << endl << endl;

G3.printGraph ();
cout << "Neighbors of second node are:  ";
for (int i = 0; i < G3.getV (); i++)
{
	x = G3.getA (1,i);
	if (x == 1)
	{
		cout << i << " ";
	}
}
G3.BFS ();
G3.DFS ();
G3.ArtPts ();
cout << endl << "________________________________________________________________________________" << endl << endl;

G4.printGraph ();
cout << "Neighbors of second node are:  ";
for (int i = 0; i < G4.getV (); i++)
{
	x = G4.getA (1,i);
	if (x == 1)
	{
		cout << i << " ";
	}
}
G4.BFS ();
G4.DFS ();
G4.ArtPts ();
cout << endl << "________________________________________________________________________________" << endl << endl;

G5.printGraph ();
cout << "Neighbors of second node are:  ";
for (int i = 0; i < G5.getV (); i++)
{
	x = G5.getA (1,i);
	if (x == 1)
	{
		cout << i << " ";
	}
}
G5.BFS ();
G5.DFS ();
G5.ArtPts ();
cout << endl << "________________________________________________________________________________" << endl << endl;

	system("PAUSE");
	return 0;
}